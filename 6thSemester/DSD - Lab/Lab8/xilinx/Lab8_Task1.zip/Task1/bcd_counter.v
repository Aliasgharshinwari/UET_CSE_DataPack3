`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    11:24:44 04/22/2024 
// Design Name: 
// Module Name:    bcd_counter 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module bcd_counter(
	input CLK,
	input CLR,
	output reg [3:0]Q
	);
	
	always@(negedge CLK) begin
	
	if(Q == 4'd9)
		Q = 4'd0;
	else
		Q = Q + 1; 
	end
	
endmodule
