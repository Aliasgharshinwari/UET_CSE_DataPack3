`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    11:52:19 04/22/2024 
// Design Name: 
// Module Name:    Top 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Top(
	input CLK,
	input RST,
	output [7:0]SEG,
	output [2:0]EnablePins
 );
	wire [3:0]BCD_SEG_U, BCD_SEG_T, BCD_SEG_H;
	wire [7:0]SEG_U, SEG_T, SEG_H;
	
	wire [17:0] count;
	
	wire SLOW_CLK;
	
	clock_divider divider(CLK, SLOW_CLK);
	
	three_BCD three_bcd(SLOW_CLK, RST, BCD_SEG_U, BCD_SEG_T, BCD_SEG_H);

	BCD_to_SevenSeg bcd_decoder1(BCD_SEG_U, SEG_U);
	BCD_to_SevenSeg bcd_decoder2(BCD_SEG_T, SEG_T);
	BCD_to_SevenSeg bcd_decoder3(BCD_SEG_H, SEG_H);
	
	Counter18bit counter18( CLK, RST, count);

	
	Mux4x1 mux(count[17:16], SEG_U, SEG_T, SEG_H, SEG);
	
	Decoder2x4 decoder(count[17:16], EnablePins);
	


endmodule
