`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    11:29:37 04/22/2024 
// Design Name: 
// Module Name:    clock_divider 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module clock_divider(
    input clk_in,          
    output reg clk_out
);
   reg [27:0] counter = 28'd0;
	parameter divisor = 28'd100000000; //Divides the input clock by 100. 
	
    always @(posedge clk_in) begin
		counter <= counter + 28'd1;
        
		if (counter >= (divisor - 1))  
            counter <= 28'd0;
	
	 clk_out <=(counter < divisor/2)?1'b1:1'b0; // Assign 1 for half cycle and 0 for 
		end	// the other half
    endmodule    
