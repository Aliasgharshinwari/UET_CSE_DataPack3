`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    11:55:25 04/22/2024 
// Design Name: 
// Module Name:    three_BCD 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module three_BCD(
	input CLK,
	input CLR,
	output [3:0] BCDU,
	output [3:0] BCDT,
	output [3:0] BCDH
 );
			bcd_counter bcdU(CLK,CLR,BCDU);
			bcd_counter bcdT(BCDU[3],CLR,BCDT);
			bcd_counter bcdH(BCDT[3],CLR,BCDH);
			
endmodule
