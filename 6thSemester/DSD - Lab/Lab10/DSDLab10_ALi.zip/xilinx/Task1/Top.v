module Top( CLK, RST, RST_BTN, BTN0, BTN1, LED, SEVENSEG);
	
	input CLK, RST, BTN0, BTN1, RST_BTN;
	
	output LED;
	output [7:0]SEVENSEG;
	
	wire SLOW_CLOCK;
	//wire synch_btn0, synch_btn1, synch_rst;
	
	wire pulse0, pulse1, RST_Pulse;
	
	wire [3:0]bcd;
	
	clock_divider divider(CLK, SLOW_CLOCK);
	lock_fsm2 my_fsm( pulse0, pulse1, SLOW_CLOCK, RST_Pulse, LED, bcd);

	btn_module b0(BTN0, SLOW_CLOCK, RST,  pulse0);
	btn_module b1(BTN1, SLOW_CLOCK, RST,  pulse1);
	btn_module b2(RST_BTN, SLOW_CLOCK, RST,  RST_Pulse);

/*	
	synchronizer s1(SLOW_CLOCK, BTN0, RST, synch_btn0);
	level_to_pulse lp1(synch_btn0, SLOW_CLOCK, RST, pulse0);
	
	synchronizer s2(SLOW_CLOCK, BTN1, RST, synch_btn1);
	level_to_pulse lp2(synch_btn1, SLOW_CLOCK, RST, pulse1);
	
	synchronizer s3(SLOW_CLOCK, RST_BTN, RST, synch_rst);
	level_to_pulse lp3(synch_rst, SLOW_CLOCK, RST, RST_pulse);
	*/
	BCD_to_SevenSeg(bcd, SEVENSEG);
	
endmodule
