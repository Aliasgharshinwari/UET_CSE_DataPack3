#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>

int main() {
	
	
	int fd[2];
	int br, bw;
	
	char buff[100];
	
	int p = pipe(fd);
	
	if(p == -1)
		perror("Pipe Failed");
	
	int x = fork();
	
	if(x == 0){//Child Code
		br = read(STDIN_FILENO, buff, 100);
		bw = write(fd[1], buff, br);
	}
	
	else{
		br = read(fd[0], buff, 100);
		printf("Parent Recieved: %s", buff);
	}
	return 0;
}

