#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/wait.h>
#include<sys/stat.h>
#include<errno.h>
#include<string.h>

int main(){
	int perm = S_IRWXU;
	char buff[100];
	int br = -1; 
	int bw;
	int nrf;
	
	struct timeval mytime;
	mytime.tv_sec = 2;
	mytime.tv_usec = 0;

	int r = mkfifo("chatfifo", perm);
	
	if(r == -1 && errno != EEXIST){
		perror("mkfifo failed");
		return -1;
	}
	int fd = open("chatfifo", O_RDWR);

	fd_set myreadset;

	while(1){
		
		FD_ZERO(&myreadset);
		FD_SET(fd, &myreadset);	
		FD_SET(STDIN_FILENO, &myreadset);	
				
		int maxfd = (STDIN_FILENO > fd) ? STDIN_FILENO: fd;
	
		//printf("Before Select \n");
	
		nrf = select(maxfd + 1, &myreadset, NULL, NULL,  NULL);
		//printf("After Select nrf = %d\n", nrf);
		
			
		if(FD_ISSET(STDIN_FILENO, &myreadset)){
		
			//printf("INSIDE IF 1\n");
			br = read(STDIN_FILENO, buff, 255);
			bw = write(fd, buff, br);
			

		}
		
		if(FD_ISSET(fd, &myreadset)){
		
			//printf("INSIDE IF 2\n");
			//	bw = write(STDOUT_FILENO, buff, br);
			
			//while(br = read(fd, buff, 255) != 0)
			//	bw = write(STDOUT_FILENO, buff, br);
				
			
			br = read(fd, buff, 256);
			
			bw = write(STDOUT_FILENO, buff, br);

			//printf("Recieved from Process %d: %s\n", getpid(), buff);
		}
	
		
		if(buff[0] == 'G' && buff[1] == 'B' ){
			printf("STRCMP");	
			break;
		}
	}
	
	unlink("chatfifo");
	return 0;
}
