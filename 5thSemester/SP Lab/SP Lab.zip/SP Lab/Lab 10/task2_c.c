#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define NUM_CHILDREN 5

int main() {
    int fd[2];
    pid_t child_pid;
    char message[] = "Hello from parent!\n";
    char readbuffer[80];

    // Create a pipe
    if (pipe(fd) == -1) {
        perror("pipe");
        exit(1);
    }

    for (int i = 0; i < NUM_CHILDREN; ++i) {
        child_pid = fork();
        if (child_pid == -1) {
            perror("fork");
            exit(1);
        }

        // Child process
        if (child_pid == 0) {
            close(fd[1]); // Close unused write end

            // Read from pipe and print to stdout
            while (read(fd[0], readbuffer, sizeof(readbuffer)) > 0) {
                printf("Child %d received: %s", i, readbuffer);
            }
            close(fd[0]); // Close read end
            exit(0);
        }
    }

    // Parent process
    close(fd[0]); // Close unused read end

    // Write to pipe
    write(fd[1], message, sizeof(message));
    close(fd[1]); // Close write end after writing

    // Wait for all children to exit
    while (wait(NULL) > 0);

    return 0;
}

