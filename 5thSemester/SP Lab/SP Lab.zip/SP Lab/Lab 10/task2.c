#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>

int main() {
	
	int fd[2];
	int br, bw;
	int n = 5;
	int pid, r;
	int i;
	char buff[100];
	
	pipe(fd);
	
	for(i = 0; i<n; i++){
	
		pid = fork();
		
		if(pid == 0){
			break;
		}
	
	}
	
	if(pid > 0){
		br = read(STDIN_FILENO, buff, sizeof(buff));
		
		for(i = 0; i<n; i++)
			bw = write(fd[1], buff, br);
		
	}
	
	else{
		br = read(fd[0], buff, 6);
		printf("Child %d Recieved: %s", i, buff);
		
	}
	
	
	if(pid > 0){
		for(i = 0; i<n; i++)
			r = wait(NULL);
	}
	
	return 0;
}

