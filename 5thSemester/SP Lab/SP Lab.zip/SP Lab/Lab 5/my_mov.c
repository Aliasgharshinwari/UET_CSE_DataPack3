#include<stdio.h>
//#include<sys/wait.h>
#include<unistd.h>
#include<string.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<errno.h>
#include<stdlib.h>

int main(int argc, char *argv[]){
	
	
	int fd1 = open(argv[1], O_RDONLY);
	if(fd1 == -1){
		fprintf(stderr, "%s", strerror(errno));
		//perror("Error: ");
	}

	int fd2 = open(argv[2], O_WRONLY | O_CREAT | O_APPEND, S_IRUSR);
	
	char bffr[1000];
		
	int br,bw;
	while((br = read(fd1, bffr, sizeof(bffr))) != 0){
		if(br == -1){
//			fprintf(STDERR, strerror(errno));
		}
		//br = read(fd1, bffr, sizeof(bffr));
		//printf("br = %d\n", br);
		bw = write(fd2, bffr, br);
	}
	
	//close(fd1);
	int u = unlink(argv[1]);
	if(u == -1){
//		fprintf(STDERR, strerror(errno));
	}
	close(fd2);
	return 0;
}
