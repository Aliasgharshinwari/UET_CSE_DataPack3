#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>

int factorial(int n){
	int fact = 1;
	for(int i = 1; i<n; i++)
		fact *= i;
	
	return fact;
}

int main(int argc, char *argv[]){
	int pid;
	int stat;

	printf("Parent ID = %d\n",getpid());

	for(int i = 1; i <= argc; i++ ){
		pid = fork();
		if(pid == 0){
		 	printf("I am child %d and my PID is %d\n",i,getpid());
			return factorial(atoi(argv[i]));
		}
	
	}
	
	if(pid > 0){
		for(int j = 1; j<= argc; j++){
			int r = wait(&stat);

			if(WIFEXITED(stat)){
				printf("Child %d Terminated with factorial = %d\n", j ,WEXITSTATUS(stat));
			}
		}
		printf("Parent Succesfully Terminated \n");
	}

	return 0;
}
