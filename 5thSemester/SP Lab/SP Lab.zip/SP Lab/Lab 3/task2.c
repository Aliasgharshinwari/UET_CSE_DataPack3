#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>


int main(int argc, char* argv[]){
	int pid;
	int r;
	printf("Parent with PID = %d\n",getpid());
	for(int i=1;  i<=atoi(argv[1]); i++){
		pid = fork();
		if(pid == 0){
			printf("In Child Process %d with PID = %d and PPID = %d\n", i, getpid(), getppid());
			break;
		}
	}
	
	if(pid > 0){
		for(int j=0; j<10; j++){
			r = wait(NULL);
		}

		printf("Parent with PID = %d\n", getpid());
	}
	return 0;
}
