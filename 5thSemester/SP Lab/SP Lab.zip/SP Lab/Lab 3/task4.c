#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>

int main(int argc, char* argv[]){
	
	int pid,r,status;
	int i;
	for(i = 1; i <= atoi(argv[1]); i++){
		pid = fork();
		if(pid > 0){
			printf("Parent Process %d with PID = %d and PPID = %d \n", i , getpid(), getppid());
			break;
		}
	
		if(pid == 0){
			printf("Child Process %d with PID = %d and PPID = %d \n",i,getpid(),getppid());
		}
	}

	return 0;

}
