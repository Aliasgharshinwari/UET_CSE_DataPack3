#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>

int main(int argc, char* argv[]){
	
	int pid,r,status;
	int i;
	for(i = 1; i <= atoi(argv[1]); i++){
		pid = fork();
		if(pid > 0){
			printf("Process %d with PID = %d and PPID = %d and Child ID = %d \n", i , getpid(), getppid() ,pid );
			break;
		}
	
		if(pid == 0){
			//printf("Child Process %d with PID = %d and PPID = %d \n",i,getpid(),getppid());
		}
	}
	
	if(pid > 0){
		r = wait(&status);

		
	}

	return 0;

}
