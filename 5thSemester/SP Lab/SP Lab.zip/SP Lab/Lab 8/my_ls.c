#include<stdio.h>
#include<errno.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/stat.h>
#include<dirent.h>
#include<string.h>
#include<pwd.h>
#include<grp.h>

void ls(struct dirent *dir_p, DIR *dir_vp){

	//while((dir_p = readdir(dir_vp)) != NULL){
	while(1){
		dir_p = readdir(dir_vp);
		
		if(dir_p == NULL){
			break;
		}
			
		if(!strcmp(dir_p->d_name, ".") || !strcmp(dir_p->d_name, "..") )
			continue;
			
		printf("%s  ", dir_p->d_name);
			
	}
}

void ls_l(struct dirent *dir_p, DIR *dir_vp, struct stat my_stats){
	struct passwd *p;
	struct group *g;
	
	while(1){
		dir_p = readdir(dir_vp);
		stat(dir_p->d_name, &my_stats);
		
		p = getpwuid(my_stats.st_uid);
		g = getgrgid(my_stats.st_gid);
			
		if(dir_p == NULL){
			break;
		}
			
		if(!strcmp(dir_p->d_name, ".") || !strcmp(dir_p->d_name, "..")){
			continue;
		}
		
		printf("Name = %s \t S = %ld \t, GID = %s\t UID = %s\t Links = %ld\t", dir_p->d_name, (long int)my_stats.st_size, p->pw_name,g->gr_name ,(long int)my_stats.st_nlink);

		//Permissions and type of file
		printf("%c", S_ISDIR(my_stats.st_mode) ? 'd' : '-');
		printf("%c", (S_IRUSR & my_stats.st_mode) ? 'r' : '-');
		printf("%c", (S_IWUSR & my_stats.st_mode) ? 'w' : '-');
		printf("%c", (S_IXUSR & my_stats.st_mode) ? 'x' : '-');
		printf("%c", (S_IROTH & my_stats.st_mode) ? 'r' : '-');
		printf("%c", (S_IWOTH & my_stats.st_mode) ? 'w' : '-');
		printf("%c", (S_IXOTH & my_stats.st_mode) ? 'x' : '-');
		printf("%c", (S_IRGRP & my_stats.st_mode) ? 'r' : '-');
		printf("%c", (S_IWGRP & my_stats.st_mode) ? 'w' : '-');
		printf("%c", (S_IXGRP & my_stats.st_mode) ? 'x' : '-');
		

		printf("\n");
			}

}


int main(int argc, char* argv[]){

	char n[100];
	struct dirent *direntp;
	struct stat mystats;

	DIR *dirvp = opendir(getcwd(n, sizeof(n)));


	if(argc == 1){
		ls(direntp, dirvp);

	}

	else if(argc == 2 && !strcmp(argv[1], "-l")){
		ls_l(direntp, dirvp, mystats);	
		}
	
	else{
		fprintf(stderr, "Arguments Invalid\n");
	}
	
	return 0;
}
