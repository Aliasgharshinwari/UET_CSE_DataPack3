#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<errno.h>
#include<string.h>

int main(){
	
	int pid;	
	pid = fork();
	
	if(pid == 0){
		printf("In Child Process \n");
		int x =wait(NULL);
		if(x == -1){
			perror("Error for Child");
			printf("The Error is: %s\n",strerror(errno));
		}
	}
	else if(pid > 0){
		printf("In Parent Process \n");
		int x = wait(NULL);
		printf("Child terminated succesfully \n");
		if(x == -1){
			perror("Error for Parent");
			printf("The Error is: %s\n", strerror(errno));
		}	
	}

	return 0;
}
