#include<stdio.h>

int main(int argc, char *argv[]){

	static int arr[100] = {2,3,4,2,1};
	return 0;
}
