#include<stdio.h>
#include<unistd.h>

int main(){

	//int fd = close(3);
	if(close(3) == -1)
		perror("Error");
	else
		printf("File Closed Succesfully\n");
	return 0;
}
