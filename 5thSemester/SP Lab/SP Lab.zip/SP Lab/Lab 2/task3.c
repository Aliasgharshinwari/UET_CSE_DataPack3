#include<stdio.h>
#include<unistd.h>
#include<errno.h>
#include<string.h>

int main(){

	//int fd = close(3);

	//perror("Error");
	//printf("Error:%s\n",strerror(errno));
	
	int f = close(0);
	perror("");
	
	return 0;
}
