#include<stdio.h>
//#include<sys/wait.h>
#include<unistd.h>
#include<string.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<errno.h>
#include<stdlib.h>

int main(int argc, char *argv[]){
	
	int r, src, dst;
	int br, bw;
	char bffr[1000];
	
	if(argc == 1){//First case
		while((br = read(STDIN_FILENO, bffr, sizeof(bffr))) != 0){
			if(br == -1)
				fprintf(stderr, "%s", strerror(errno));			
			
			bw = write(STDOUT_FILENO, bffr,br);
			
			if(bw == -1)
				fprintf(stderr, "%s", strerror(errno));			
			
		}
	}
	if(argc == 2){//second case
		src = open(argv[1], O_RDONLY);
		
		while((br = read(src, bffr, sizeof(bffr))) != 0){
			if(br == -1)
				fprintf(stderr, "%s", strerror(errno));			
		
			bw = write(STDOUT_FILENO, bffr,br);
			if(bw == -1)
				fprintf(stderr, "%s", strerror(errno));			
				
		}
	}

	else if(argc == 3){//Third Case
		dst = open(argv[2], O_WRONLY);
		while((br = read(STDIN_FILENO, bffr, sizeof(bffr))) != 0){
			if(br == -1)
				fprintf(stderr, "%s", strerror(errno));			
		
			bw = write(dst, bffr,br);
			if(bw == -1)
				fprintf(stderr, "%s", strerror(errno));			
		
		}
	}
	
	else if(argc == 4){//Fourth Case
		src = open(argv[1], O_RDONLY); 
		dst = open(argv[3], O_WRONLY);
		while((br = read(src, bffr, sizeof(bffr))) != 0){
			if(br == -1)
				fprintf(stderr, "%s", strerror(errno));			
			
			bw = write(dst, bffr,br);
			if(bw == -1)
				fprintf(stderr, "%s", strerror(errno));			
		
		}
	}

	else{
		fprintf(stderr, "%s", strerror(errno));
	}

	
	return 0;
}
