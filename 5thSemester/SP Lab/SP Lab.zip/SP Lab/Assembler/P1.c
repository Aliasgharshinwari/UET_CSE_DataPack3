#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 100
#define MAX_SYMBOL_TABLE_SIZE 100

// Define opcodes for a hypothetical instruction set
#define ADD_OPCODE 0
#define SUB_OPCODE 1
#define MOV_OPCODE 2
#define HLT_OPCODE 3

// Structure to represent a symbol table entry
typedef struct {
    char label[20];
    int address;
} SymbolEntry;

// Global variables
int memory[MAX_SYMBOL_TABLE_SIZE];
SymbolEntry symbolTable[MAX_SYMBOL_TABLE_SIZE];
int symbolTableSize = 0;

// Function to add a label to the symbol table
void addLabel(char *label, int address) {
    strcpy(symbolTable[symbolTableSize].label, label);
    symbolTable[symbolTableSize].address = address;
    symbolTableSize++;
}

// Function to find the address of a label in the symbol table
int findLabelAddress(char *label) {
    for (int i = 0; i < symbolTableSize; ++i) {
        if (strcmp(symbolTable[i].label, label) == 0) {
            return symbolTable[i].address;
        }
    }
    return -1;  // Label not found
}

// Function to assemble an instruction
int assembleInstruction(char *instruction) {
    char opcode[4], operand1[20], operand2[20];
    int address;

    sscanf(instruction, "%s %s %s", opcode, operand1, operand2);

    if (strcmp(opcode, "ADD") == 0) {
        address = atoi(operand2);
        return (ADD_OPCODE << 24) | (atoi(operand1) << 16) | address;
    } else if (strcmp(opcode, "SUB") == 0) {
        address = atoi(operand2);
        return (SUB_OPCODE << 24) | (atoi(operand1) << 16) | address;
    } else if (strcmp(opcode, "MOV") == 0) {
        address = findLabelAddress(operand2);
        if (address == -1) {
            address = atoi(operand2);
        }
        return (MOV_OPCODE << 24) | (atoi(operand1) << 16) | address;
    } else if (strcmp(opcode, "HLT") == 0) {
        return (HLT_OPCODE << 24);
    }

    return -1;  // Invalid instruction
}

int main() {
    char line[MAX_LINE_LENGTH];

    // Example assembly code
    const char *assemblyCode[] = {
        "ADD 1 2",
        "SUB 3 4",
        "MOV 5 label1",
        "HLT",
        "label1: MOV 6 7",
    };

    // Assemble the code
    for (int i = 0; i < sizeof(assemblyCode) / sizeof(assemblyCode[0]); ++i) {
        int machineCode = assembleInstruction(assemblyCode[i]);
        if (machineCode == -1) {
            printf("Error: Invalid instruction '%s'\n", assemblyCode[i]);
            return 1;
        }
        memory[i] = machineCode;
    }

    // Display the assembled code
    printf("Assembled Code:\n");
    for (int i = 0; i < sizeof(assemblyCode) / sizeof(assemblyCode[0]); ++i) {
        printf("%08X\n", memory[i]);
    }

    return 0;
}

