#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>

sigset_t myset;
int x;
void my_wait(){

	if(x > 0){
	
		sigdelset(&myset, SIGCHLD);//UNBLOCK SIGCHLD
		sigprocmask(SIG_SETMASK, &myset, NULL);
		pause();
		printf("\nParent has been terminated..\n");

	}
	
}

void my_handler(int sig_no){
	
	printf("\nCHild has been terminated..\n");
}

int main(int argc, char* argv[]){
	
	struct sigaction my_action;
	
	my_action.sa_flags = 0;
	my_action.sa_handler = my_handler;
	sigemptyset(&my_action.sa_mask); 
	
	sigemptyset(&myset); 
	sigfillset(&myset);//BLOCK ALL SIGNALS
		
	sigaction(SIGCHLD, &my_action, NULL);

	sigprocmask(SIG_SETMASK, &myset, NULL);

	x = fork();
	
	if(x > 0){
		printf("\nParent Waiting..\n");
		my_wait();				
		printf("\nParent Waited succesfully..\n");
	}
	
	return 0;
}
