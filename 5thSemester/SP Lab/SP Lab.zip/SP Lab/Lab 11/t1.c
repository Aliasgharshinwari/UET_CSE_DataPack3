#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <signal.h>

int x;
void mywait()
{
    while (x == 0)
        ;
    printf("parent terminated\n");
}
void myhandler(int no)
{
    printf("child terminated\n");
    x = 1;
}
int main()
{

    struct sigaction act;
    act.sa_handler = myhandler;
    sigaction(SIGCHLD, &act, NULL);

    int y = fork();
    if (y > 0)
        mywait();
}
