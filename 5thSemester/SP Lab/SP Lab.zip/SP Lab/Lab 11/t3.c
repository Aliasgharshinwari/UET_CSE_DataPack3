#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>


sigset_t myset;
int x;

void my_wait(){

	if(x > 0)
		sigsuspend(&myset);
}

void my_handler(int sig_no){
	
	printf("\nCHild has been terminated..\n");
	//raise(sig_no);
}

int main(int argc, char* argv[]){
	
	struct sigaction my_action;
	
	my_action.sa_flags = 0;
	my_action.sa_handler = my_handler;
	sigemptyset(&my_action.sa_mask); 
	
	sigemptyset(&myset); 
	sigfillset(&myset);//BLOCK ALL SIGNALS
	sigdelset(&myset, SIGCHLD);
		
	sigaction(SIGCHLD, &my_action, NULL);

	x = fork();
	
	if(x > 0){
		printf("\nParent Waiting..\n");
		my_wait();				
	}
	
	return 0;
}
