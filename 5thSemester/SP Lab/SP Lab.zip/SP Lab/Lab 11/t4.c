#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>
#include<string.h>

sigset_t myset;
int x;

void my_wait(){
	int y;
	if(x > 0)
		sigwait(&myset, &y);
}

void my_handler(int sig_no){
	
	printf("\nCHild has been terminated..\n");
	printf("%s\n", strdup(sys_siglist[sig_no]));
}

int main(int argc, char* argv[]){
	
	struct sigaction my_action;
	
	my_action.sa_flags = 0;
	my_action.sa_handler = my_handler;
	sigemptyset(&my_action.sa_mask); 
	
	sigemptyset(&myset); 
	sigaddset(&myset, SIGCHLD);
	sigaction(SIGCHLD, &my_action, NULL);

	x = fork();
	
	if(x > 0){
		printf("\nParent Waiting..\n");
		my_wait();			
		printf("\nParent Waited succesfully..\n");	
	}
	
	else{
		sleep(2);
	}	
	return 0;
}
