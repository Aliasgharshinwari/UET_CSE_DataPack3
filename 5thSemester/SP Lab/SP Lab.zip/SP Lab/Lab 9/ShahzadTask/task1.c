#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<dirent.h>
#include<sys/stat.h>

void depthfirst(char *dirname){
	struct stat statbuff;
	//if((stat(dirname,&statbuff))==-1){
        //                perror("stat failed\n");
        //               return;
        //}

	//opening directory
	DIR *dirp;
        if((dirp=opendir(dirname))==NULL){
                perror("open failed.\n");
		return;
        }

	//reading directory
	struct dirent *direntp;
	//printf("%s\n",direntp->d_name);
	if((direntp = readdir(dirp))==NULL){
		perror("readdir failed.\n");
		return;
	}
	while(direntp!=NULL){
		//printf("%s\n",direntp->d_name);
		//if((stat(direntp->d_name,&statbuff))==-1){
		//	perror("stat failed\n");
		//	return;
		//}
		//if((chdir(direntp->d_name))==-1){
		//	printf("%s\n",direntp->d_name);
		//	perror("chdir failed\n");
		//	return;
		//}
		direntp = readdir(dirp);
		printf("%s\n",direntp->d_name);
		stat(direntp->d_name,&statbuff);
		
		if(S_ISDIR(statbuff.st_mode)){
			//printf("%d\n",S_ISDIR(statbuff.st_mode));
			//printf("%s , isdir\n",direntp->d_name);
			//depthfirst(direntp->d_name);
			//chdir("..");
		}
		
		else{
			printf("%s, isfile\n",direntp->d_name);
			//depthfirst(direntp->d_name);
		}
		
		
	}
	closedir(dirp);

}

int main(){
	depthfirst("/home/ali/Desktop/SP Lab");
	return 0;
}

