#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>

void depthFirst(char *path, char *name) {
	
  	char dir_buff[1000];
  	char buff[1000];
  	char dir_name[1000];

  	strcpy(buff, path);
      	
//      chdir(buff);

	struct dirent *entry;
	struct stat statbuff;

  	DIR *dir = opendir(buff);

	   
	while ((entry = readdir(dir)) != NULL) {
		
		if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) {
        	    continue;
        	}

		stat(entry->d_name, &statbuff);
       	
       	if (!strcmp(entry->d_name, name)) {
        	    printf("File Found in: %s\n", getcwd(dir_buff, 1000));
        	}

	
  	strcpy(dir_name, entry->d_name);

        if (S_ISDIR(statbuff.st_mode)) {
            	depthFirst(dir_name, name);
		//chdir("..");
        }
	
//	else{
//		printf("%s", entry->d_name);
//	}

        //printf("Visited: %s\n",entry->d_name);
    }

    closedir(dir);
    
}

int main(int argc, char* argv[]) {
	char *rootPath = ".";   //char *rootPath2 = "ali ";
   //char *rootPath3 = "asghar";
   //strcat(rootPath1, rootPath2);
   //strcat(rootPath1, rootPath3);
    
 //   printf("%s\n", rootPath1);
    depthFirst(rootPath, argv[1]);
    return 0;
}

