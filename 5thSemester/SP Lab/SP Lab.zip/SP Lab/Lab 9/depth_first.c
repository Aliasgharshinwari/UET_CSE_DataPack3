#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>

void depthFirst(char *path, int n) {
    //chdir(path);
    
    DIR *dir = opendir(path);
    
    if (dir == NULL) {
       // perror("Failed to open directory");
        return;
    }

    

    struct dirent *entry;
    struct stat statbuff;

    while ((entry = readdir(dir)) != NULL) {
        stat(entry->d_name, &statbuff);

        if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) {
            continue;
        }

        // Allocate memory for the full path
        char *fullPath = malloc(strlen(path) + strlen(entry->d_name) + 2);
        if (fullPath == NULL) {
            fprintf(stderr, "Memory allocation failed\n");
            exit(EXIT_FAILURE);
        }

        // Construct the full path
        strcpy(fullPath, path);
        strcat(fullPath, "/");
        strcat(fullPath, entry->d_name);

        for(int i =0; i<n; i++)
            printf("--");

        printf("%s\n", entry->d_name);

        if (S_ISDIR(statbuff.st_mode)) {
            depthFirst(fullPath, n+1);
            //chdir("..");
        }

        free(fullPath);
    }

    closedir(dir);
}

int main() {
    char *rootPath = "."; 
    depthFirst(rootPath, 0);
    return 0;
}

