#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>

void breadthFirst(char *path) {
	struct dirent *entry;
	struct stat statbuff;
	
	char buff[1000];
  	char dir_name[1000];
  	
	strcpy(buff, path);
        
  	DIR *dir = opendir(".");
	
     	chdir(buff);

    while ((entry = readdir(dir)) != NULL) {
	  
        if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) {
            continue;
        }

	stat(entry->d_name, &statbuff);
      	strcpy(dir_name, entry->d_name);
        printf("%s\n",dir_name);

    }
    
      	
	
	rewinddir(dir);
    
    while ((entry = readdir(dir)) != NULL) {

//	printf("2nd Loop\n");
  
        if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, ".."))
            continue;

        
	stat(entry->d_name, &statbuff);
	
        if (S_ISDIR(statbuff.st_mode)) {
		//printf("2nd Loop\n");  
            	breadthFirst(entry->d_name);
		chdir("..");
        }
        
    }
    closedir(dir);
}

int main() {
	char *rootPath = ".";   //char *rootPath2 = "ali ";
   //char *rootPath3 = "asghar";
   //strcat(rootPath1, rootPath2);
   //strcat(rootPath1, rootPath3);
    
 //   printf("%s\n", rootPath1);
    breadthFirst(rootPath);
    return 0;
}

