#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>

int depth_first(char *root){
	DIR *dirp;
	static int ret = 0;
	struct dirent *direntp;
	struct stat statbuff;
	dirp = opendir(root);
	
	if(dirp == NULL){
		return -1;
		}
	int rett = chdir(root);
	if(rett == -1){
		return -1;
		}
	while((direntp = readdir(dirp)) != NULL){
		stat(direntp->d_name, &statbuff);
		
		if(!strcmp(direntp->d_name, "..") || !strcmp(direntp->d_name, ".") ){
			continue;			
		}
		
		else if(S_ISDIR(statbuff.st_mode)){
			depth_first(direntp->d_name);
			chdir("..");
			}
		else{
			chdir("..");
			}
			
		printf("%s\n",direntp->d_name);
		}
	}
int main(int argc, char **argv){
	
	depth_first(".");
	return 0;
	}

