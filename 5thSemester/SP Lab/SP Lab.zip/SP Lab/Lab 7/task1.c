#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<errno.h>
#include<stdlib.h>

int main(int argc, char *argv[]){
	
	int perm = S_IRWXU;

	int fd1 = open(argv[1], O_RDONLY);
	if(fd1 == -1)
		fprintf(stderr, "%s", strerror(errno));


	int fd2 = open(argv[2], O_RDONLY);
	if(fd2 == -1)
		fprintf(stderr, "%s", strerror(errno));

	int fd3 = open(argv[3], O_WRONLY | O_CREAT | O_APPEND, perm);
	if(fd3 == -1)
		fprintf(stderr, "%s", strerror(errno));

	int fd4 = open(argv[4], O_WRONLY | O_CREAT | O_APPEND, perm);
	if(fd4 == -1)
		fprintf(stderr, "%s", strerror(errno));

	char bffr[1000];
		
	int br,bw;
	while((br = read(fd1, bffr, sizeof(bffr))) != 0){
		if(br == -1)
			fprintf(stderr, "%s", strerror(errno));

		bw = write(fd3, bffr, br);
	}
	
	while((br = read(fd2, bffr, sizeof(bffr))) != 0){
		bw = write(fd4, bffr, br);
	}
	
	close(fd1);
	close(fd2);
	close(fd3);
	close(fd4);
	return 0;
}
