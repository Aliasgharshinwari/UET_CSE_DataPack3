#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int main(int argc, char* argv[]){
	int perm = S_IRWXU;

	int fd_args[argc - 1];
	int i;

	for(i =0; i<argc - 1; i++){
		fd_args[i] = open(argv[i + 1], O_RDONLY | O_CREAT, perm);
		printf("File Opened i = %d\n", i);
	}

	fd_set myreadyset;
	
	FD_ZERO(&myreadyset);

	for(i = 0; i<argc - 1; i++)
		FD_SET(fd_args[i] ,&myreadyset);


	int maxfd = fd_args[0];
	for(i = 0; i<argc - 1; i++){
		if (fd_args[i] > maxfd)
			maxfd = fd_args[i];
	}

	int nrf = select(maxfd + 1, &myreadyset, NULL, NULL, NULL);

	printf("nrf = %d\n", nrf);

	for(i = 0; i<argc - 1; i++){
		if(FD_ISSET(fd_args[i], &myreadyset))
			printf("File %d Ready\n", i);
	}

	return 0;
}

