#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>

//struct timeval mytime;
	
void my_delay(struct timeval time_obj){

	int s = select(1,NULL,NULL,NULL, &time_obj);
	if(s == -1)
		fprintf(stderr, "%s", strerror(errno));

}

int main(int argc, char* argv[]){
	
	if(argc != 3){
		printf("Usage Error\n");
		return -1;
	}
	
	struct timeval mytime;
	mytime.tv_sec = atoi(argv[1]);
	mytime.tv_usec = atoi(argv[2]);
	
	my_delay(mytime);
	return 0;
}
