#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/wait.h>

int main(int argc, char* argv[]){
	int perm = S_IRWXU;
	int pid, fd1, fd2, fd3, fd4;
	int r, nrf; 
	
	char bffr[1000];
	int bw, br;	
	
	fd1 = open(argv[1], O_RDONLY | O_CREAT, perm);
	fd2 = open(argv[2], O_WRONLY | O_CREAT, perm);
	fd3= open(argv[3], O_WRONLY | O_CREAT, perm);	
				
	fd_set myreadyset;
	FD_ZERO(&myreadyset);

	FD_SET(fd1,&myreadyset);		
	FD_SET(fd2, &myreadyset);
	FD_SET(fd3, &myreadyset);
	
	
	int maxfd;
	if (fd1 > fd2 && fd1 > fd3)
		maxfd = fd1;
	else if(fd2 > fd1 && fd2 > fd3)
		maxfd = fd2;
	else
		maxfd = fd3;
		
	int i;
	
	for(i = 0; i<2; i++){
		pid = fork();
		
		if(pid == 0)
			break;
			
		
	}

	if(pid == 0){

		nrf = select(maxfd, &myreadyset, NULL, NULL, NULL);

		printf("number of ready files  = %d\n", nrf);
		if(FD_ISSET(fd1, &myreadyset)){
			
			while((br = read(fd1, bffr, sizeof(bffr))) != 0){
				if(i == 0){
					bw = write(fd2, bffr, br);
					printf("Child %d read the file:\n", i+1);				
				}
				else{ 
				 	bw = write(fd3, bffr, br);
				 	printf("Child %d read the file:\n", i+1);
				}
			}
		
		}
	}
	
	if(pid > 0){
		for(int k = 0; k<1; k++)
			r = wait(NULL);
			
	}
	return 0;
}
