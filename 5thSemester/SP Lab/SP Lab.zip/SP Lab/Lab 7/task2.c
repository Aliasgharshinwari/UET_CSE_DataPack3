#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int main(int argc, char* argv[]){
	int perm = S_IRWXU;
	int fd1 = open(argv[1], O_RDONLY);
	int fd2 = open(argv[2], O_RDONLY);
	
	fd_set myreadyset;
	
	FD_ZERO(&myreadyset);
	FD_SET(fd1, &myreadyset);
	FD_SET(fd2, &myreadyset);


	int maxfd = (fd1 > fd2) ? fd1 : fd2;

	int nrf = select(maxfd + 1, &myreadyset, NULL, NULL, NULL);

	printf("nrf = %d\n", nrf);

	if(FD_ISSET(fd1, &myreadyset))
		printf("File 1 Ready\n");

	if(FD_ISSET(fd2, &myreadyset))
		printf("File 2 Ready\n");

	return 0;
}
