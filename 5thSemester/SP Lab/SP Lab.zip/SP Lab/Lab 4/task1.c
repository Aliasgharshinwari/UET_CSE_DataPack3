#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>

int main(int argc, char* argv[]){

	int pid;
	int r;
	int status;

	for(int i = 1; i< argc; i++){
		pid = fork();

		if(pid == 0){
			execlp(argv[i], argv[i], NULL);
		}
	}

	if(pid > 0){
	for(int j = 1; j<argc; j++){
		r = wait(&status);
		if(WIFEXITED(status))
			printf("Child %d succesfully terminated with status %d\n", j , WEXITSTATUS(status));
			
		if(WIFSIGNALED(status))
			printf("Child %d was terminated with signal %d\n ",j,WTERMSIG(status));	
			
		if(WIFSTOPPED(status))
			printf("Child %d was stopped by signal %d\n", j, WSTOPSIG(status));
		}

	}
	return 0;
}
