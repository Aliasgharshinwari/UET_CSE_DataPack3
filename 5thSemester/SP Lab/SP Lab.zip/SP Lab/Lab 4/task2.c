#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>

int main(int argc, char* argv[]){

	int pid;
	int r;
	
	//printf("%d\n",x);
	for(int i = 0; i<2; i++){
		pid = fork();

		if(pid1 == 0 && i == 0){
			execl("./adder.o", "adder.o",argv[1],argv[2], NULL);
		}

		if(pid2 == 0 && i == 1){
			execl("./multiplier.o","multiplier.o", argv[1], argv[2], NULL);
		}
	}
	if(pid1 > 0){
		for(int i = 0; i<2; i++){
			r = wait(NULL);
		}
	}
	return 0;
}
