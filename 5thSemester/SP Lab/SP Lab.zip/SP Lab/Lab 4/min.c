#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>

int main(int argc, char* argv[]){

	int mini;
	//printf("argc %d",argc);
	if(argc == 1){
	
		printf("Error: Invalid Args\n");
		return -1;
	}
	mini = atoi(argv[1]);
	for(int i=1; i<argc; i++){
		if(atoi(argv[i]) < mini){
			mini = atoi(argv[i]);
		}
	}

	//printf("Minimum = %d\n",mini);
	return mini;
}
