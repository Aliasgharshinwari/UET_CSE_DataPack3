#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>

int main(int argc, char* argv[]){

	int pid;
	int r,status;

	//printf("%d\n",x);
	for(int i =0; i<2; i++){
	pid = fork();
		if(pid == 0 && i==0){
			execv("./min.o",argv);
		}

		if(pid == 0 && i==1){
			execv("./max.o", argv);
		}

	}
	for(int i = 0; i<2; i++){
		r = wait(&status);
		if(WIFEXITED(status)){
			printf("Child %d return with value %d\n", i, WEXITSTATUS(status));
		}
	}
	return 0;
}
