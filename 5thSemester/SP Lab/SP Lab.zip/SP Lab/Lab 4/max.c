#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>

int main(int argc, char* argv[]){

	int maxi;
	//printf("argc %d",argc);
	if(argc == 1){
	
		printf("Error: Invalid Args\n");
		return -1;
	}
	maxi = atoi(argv[1]);
	for(int i=1; i<argc; i++){
		if(atoi(argv[i]) > maxi){
			maxi = atoi(argv[i]);
		}
	}

	
	return maxi;
}
