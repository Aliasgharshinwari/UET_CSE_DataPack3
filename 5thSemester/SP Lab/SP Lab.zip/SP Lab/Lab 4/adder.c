#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>

int main(int argc, char* argv[]){

	int res;
	//printf("argc %d",argc);
	if(argc != 3){
	
		printf("Error: Invalid Args\n");
		return -1;
	}

	res = atoi(argv[1]) + atoi(argv[2]);
	printf("Sum = %d\n",res);
	return 0;
}
