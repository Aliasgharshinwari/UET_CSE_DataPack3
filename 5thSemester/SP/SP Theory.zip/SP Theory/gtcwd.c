#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int main(){
	char *buff = getcwd(buff, 100);
	
	printf("%s\n", buff);
	
	chdir("/home");
	
	buff = getcwd(buff, 100);
	
	printf("Changed Directory is:%s\n", buff);
		
	return 0;
}
