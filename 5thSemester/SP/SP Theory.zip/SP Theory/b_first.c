#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>

struct char_queue{
	char *str;
	struct char_queue *next;
	}*front,*rear,*newnode,*ptr;

void enqueue(char *strr){
	newnode = (struct char_queue*)malloc(sizeof(struct char_queue));
	newnode->str = strr;
	if((front == NULL) && (rear == NULL)){
		front = newnode;
		rear = newnode;
		newnode->next = NULL;
		}
	else{
		rear->next = newnode;
		newnode->next = NULL;
		rear = newnode;
		}
	}

char* dequeue(){
	char *rt;
	if((rear == NULL) && (front == NULL)){
		rt = NULL;
		}
	else if(front == rear){
		rt = front->str;
		front = NULL;
		rear = NULL;
		}
	else{
		rt = front->str;
	        front = front->next;
		}
	return rt;	
	}

char* dirpath(void){
	long maxpath;
	char *mycwdp;
	if ((maxpath = pathconf(".", _PC_PATH_MAX)) == -1) {
		perror("Failed to determine the pathname length");
		return NULL;
		}
	if ((mycwdp = (char *) malloc(maxpath)) == NULL) {
		perror("Failed to allocate space for pathname");
		return NULL;
		}
	if (getcwd(mycwdp, maxpath) == NULL) {
		perror("Failed to get current working directory");
		return NULL;
		}
	return mycwdp;
	}

int breadth_first(char *root){
	DIR *dirp;
	struct dirent *direntp;
	struct stat statbuff;
	char *temp;
	enqueue(root);
	
	while((temp = dequeue()) != NULL){
		int rett = chdir(temp);
		if(rett == -1){
			return -1;
		}
		char *path1 = dirpath();  
		printf("directory: %s\n", path1);
		dirp = opendir(path1);
		if(dirp == NULL){
			return -1;
		}
		while((direntp = readdir(dirp)) != NULL){
			rett = stat(direntp->d_name, &statbuff);
			if(rett == -1){
				return -1;
			}
			if(!strcmp(direntp->d_name, "..") || !strcmp(direntp->d_name, ".")){
				continue;			
			}
			else if(S_ISDIR(statbuff.st_mode)){
				breadth_first(direntp->d_name);
				//enqueue(direntp->d_name);
			}
		}
		chdir("..");
		closedir(dirp);
		}
	return 0;
	}

int main(int argc, char **argv){
	breadth_first(argv[1]);
	return 0;
	}

