#include <unistd.h>
#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <stdlib.h>
int makeargv(const char *s,  const char *del, char ***argvp){
	int i, numtokens;
	const char *snew;
	char *temp;
	numtokens = 0;
	if(s==NULL || del == NULL){
		return -1;
		}
	snew = s + strspn(s, del);
	if((temp = (char *)malloc(strlen((snew)+1))) == NULL){
		return -1;
		}
	strcpy(temp, snew); 
	if(strtok(temp, del) != NULL){
		for(numtokens = 1; strtok(NULL, del) != NULL; numtokens++);
		}
    	if(numtokens == 0){
		return 0;
		}
	if((*argvp = malloc((numtokens+1) * sizeof(char *))) == NULL){
		return -1;
		}
	strcpy(temp, snew);
	**argvp = strtok(temp, del);
	for(i = 1; i < numtokens; i++){
		*((*argvp)+i) = strtok(NULL, del);
		}
	*((argvp)+numtokens) = NULL;
	return numtokens;
	}	

int main(int argc, char **argv){
	DIR *dirp;
	struct dirent *direntp;
	struct stat statbuff;
	int i; 
	char **PATH;
	char *temp;
	temp = getenv("PATH");
	char *delimiter = ":";
	if(argc != 2){ return -1; }
	
	int numpaths = makeargv(temp, delimiter, &PATH);
	if(numpaths == -1){
		fprintf(stderr, "unable to create paths array");
		return -1;
		}
	for(i = 0; i < numpaths; i++){
		dirp = opendir(PATH[i]);
		while((direntp = readdir(dirp)) != NULL){
			stat(direntp -> d_name, &statbuff);
				if(S_IXUSR & statbuff.st_mode || S_IXGRP & statbuff.st_mode || S_IXGRP & statbuff.st_mode){
					if((strcmp(direntp -> d_name, argv[1])) == 0){				
						fprintf(stdout, "%s/%s\n",PATH[i], direntp->d_name);
				}
			}
		}
	}
	return 1;
	}

