#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>

int depth_first(char *root, char *file){
	DIR *dirp;
	static int ret = 0;
	struct dirent *direntp;
	struct stat statbuff;
	dirp = opendir(root);
	if(dirp == NULL){
		return -1;
		}
	int rett = chdir(root);
	if(rett == -1){
		return -1;
		}
	while((direntp = readdir(dirp)) != NULL){
		stat(direntp->d_name, &statbuff);
		
		if(!strcmp(direntp->d_name, "..") || !strcmp(direntp->d_name, ".") ){
			continue;			
			}
		else if(S_ISDIR(statbuff.st_mode)){
			depth_first(direntp->d_name, file);
			chdir("..");
			}
		else if(!strcmp(file, direntp->d_name)){
			ret += 1;
			//fprintf(stdout, "%s total files found %d\n",file,ret); 
			}
		else{
			chdir("..");
			}
			
		printf("%s\n",direntp->d_name);
		}
	}
int main(int argc, char **argv){
	if(argc != 3){
		fprintf(stderr, "usage error"); 
		return -1;
		}
	depth_first(argv[1], argv[2]);
	return 0;
	}

