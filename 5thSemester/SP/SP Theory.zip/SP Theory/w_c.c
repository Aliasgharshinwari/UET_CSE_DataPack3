#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>


int readwords(char* filename){

	int fd1 = open(filename, O_RDONLY);
	int br;	
	char bffr[2];
	
	int w = 0;
	
	while((br  = read(fd1, bffr, 2)) != 0){
		if((bffr[0] != ' ' && bffr[1] == ' ') || (bffr[0] != ' ' && bffr[1] == '\n')){
			w++;
		}
	}
	
	return w;
}

int readlines(char* filename){

	int fd1 = open(filename, O_RDONLY);
	int br;	
	char bffr[1];
	
	int l = 0;
	
	while((br  = read(fd1, bffr, 1)) != 0){
		
		if(bffr[0] == '\n')
			l++;
	}
	
	return l;	
}

int main(){
	int br = 1;
	int bw;
	char bffr[2];


	printf("Word Count = %d\n", readwords("f1.txt"));
	printf("Line Count = %d\n", readlines("f1.txt"));
	return 0;
}
