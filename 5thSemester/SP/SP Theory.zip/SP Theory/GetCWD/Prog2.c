#include<stdio.h>
#include<errno.h>
#include<stdlib.h>
#include<unistd.h>

char* get_cwd(char* bff, int size){

	return getcwd(bff, size);

}

int main(){
	char n[100];
	struct dirent *direntp;
	//struct stat mystats;

	printf("CURRENT WORKING DIR = %s\n", get_cwd(n, sizeof(n)));

	int rv = chdir("../..");
	printf("CURRENT WORKING DIR = %s\n", print_cwd(n, sizeof(n)));
	DIR *dirvp = opendir(get_cwd(n, sizeof(n)));

	while(1){
		direntp = readdir(dirvp);
		//stat(direntp->d_name, );
		if(direntp == NULL)
			break;

		printf("Dirent name = %s and it's dirent node is: %d \n", direntp->d_name, direntp->d_ino, );
	}
	return 0;
}
