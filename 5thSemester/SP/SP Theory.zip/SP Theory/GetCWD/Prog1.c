#include<stdio.h>
#include<errno.h>
#include<stdlib.h>
#include<unistd.h>

char* print_cwd(char* bff, int size){

	return getcwd(bff, size);

}

int main(){
	char n[100];

//	char* r = getcwd(n, 100);
//	char* r = get_current_dir_name();
//	printf("%s\n", n);
	printf("CURRENT WORKING DIR = %s\n", print_cwd(n, sizeof(n)));

	int rv = chdir("../..");

	printf("CURRENT WORKING DIR = %s\n", print_cwd(n, sizeof(n)));

	return 0;
}
