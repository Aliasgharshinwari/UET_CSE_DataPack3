#include<stdio.h>
#include<errno.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/stat.h>
#include<dirent.h>

int main(){
	char n[100];
	struct dirent *direntp;
	struct stat mystats;

	DIR *dirvp = opendir(getcwd(n, sizeof(n)));

	while(1){
		direntp = readdir(dirvp);
		stat(direntp->d_name, &mystats);

		if(direntp == NULL)
			break;
		
		printf("Name = %s \t S = %ld \t, GID = %ld\t UID = %ld \t Links = %ld\t", direntp->d_name, (long int)mystats.st_size,(long int) mystats.st_gid, (long int)mystats.st_uid, (long int)mystats.st_nlink);
	
		//Permissions and type of file
		printf("%c", S_ISDIR(mystats.st_mode) ? 'd' : '-');
		printf("%c", (S_IRUSR & mystats.st_mode) ? 'r' : '-');
		printf("%c", (S_IWUSR & mystats.st_mode) ? 'w' : '-');
		printf("%c", (S_IXUSR & mystats.st_mode) ? 'x' : '-');
		printf("%c", (S_IROTH & mystats.st_mode) ? 'r' : '-');
		printf("%c", (S_IWOTH & mystats.st_mode) ? 'w' : '-');
		printf("%c", (S_IXOTH & mystats.st_mode) ? 'x' : '-');
		printf("%c", (S_IRGRP & mystats.st_mode) ? 'r' : '-');
		printf("%c", (S_IWGRP & mystats.st_mode) ? 'w' : '-');
		printf("%c", (S_IXGRP & mystats.st_mode) ? 'x' : '-');
	

		printf("\n");
	}
	return 0;
}
