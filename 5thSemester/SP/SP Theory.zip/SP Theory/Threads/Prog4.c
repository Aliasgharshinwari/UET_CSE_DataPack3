#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int arr[100];
int sum = 0;

void SumArray(int start, int end){
	int local_sum = 0;
	
	printf("Start = %d and End = %d\n", start, end);	
	
	for(int j = start; j<end; j++){
		local_sum +=arr[j];
	}
	printf("Local Sum = %d\n", local_sum);
	sum = sum + local_sum;
}

int main(){

	int args[2] ={0, 1};
	
	for(int i =0; i<100; i++){
		arr[i] = i;
	}
	
	clock_t start_time, end_time;
	double cpu_time_used;
	
	start_time = clock();
	
	for(int i =0; i<2; i++){
		SumArray(args[i]*100/2, args[i]*100/2 + 100/2);
	}
	
	end_time = clock();
	
	printf("Sum of all = %d\n", sum);
	
	cpu_time_used = ((double) (end_time - start_time)) / CLOCKS_PER_SEC;
	
	printf("Time taken to execute: %f seconds\n", cpu_time_used);
	
	return 0;
}

