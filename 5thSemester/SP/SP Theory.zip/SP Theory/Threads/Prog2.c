#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

//int N = 100;

int arr[100];
int sum[3] = {0,0,0};

void *SumArray(void* arg){
	int local_sum = 0;
	
	int start = *(int *)arg * 100/2;
	int end = start + 100/2;
	
	 
	printf("Arg = %d\n", *((int *)arg));
	printf("Start = %d and End = %d\n", start, end);	
	
	for(int j = start; j<end; j++){
		local_sum +=arr[j];
	}
	printf("Local Sum = %d\n", local_sum);
	sum[*(int *)arg] = sum[*(int *)arg] + local_sum;
}

int main(){

	pthread_t tid[2];
	
	int args[2] ={0, 1};
	
	for(int i =0; i<100; i++){
		arr[i] = i;
	}
	
	for(int i =0; i<2; i++){
		pthread_create(&tid[i], NULL, SumArray, (void *)&args[i]);
	}
	
	for(int i =0; i<2; i++){
		pthread_join(tid[i], NULL);
	}
	
	sum[2] = sum[0] + sum[1];
	
	printf("Sum of all = %d\n", sum[2]);
	return 0;
}
