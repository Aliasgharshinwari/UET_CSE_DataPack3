#include<stdio.h>
#include<errno.h>
#include<stdlib.h>

int main(){
	char* name;
	name = malloc(100);
	int i;
	
	printf("Enter name\n");
	scanf("%s", name);
	printf("%s", name);
//	for(i = 0; i<sys_nerr; i++){
//		errno = i;
//		perror("Error");
//	}
	
//	printf("\n%d",i);
	return 0;
}
