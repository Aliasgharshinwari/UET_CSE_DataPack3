#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>

int main(int argc, char **argv){
    char *path = strtok(getenv("PATH"), ":");
    struct dirent *dp;
    struct stat st;

    if(argc != 2) return -1;

    while(path) {
        DIR *dir = opendir(path);
        if(dir) {
            while((dp = readdir(dir))) {
                if(!strcmp(dp->d_name, argv[1]) && !stat(dp->d_name, &st) && (st.st_mode & S_IXUSR)) {
                    printf("%s/%s\n", path, dp->d_name);
                }
            }
            closedir(dir);
        }
        path = strtok(NULL, ":");
    }
    return 0;
}

