#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(int argc, char* argv[]){
	

	char* str1 = "AB";
	char* str2 = "B";
	
	int res = strcmp(str1, str2);
	printf("%d\n", res);
	return 0;
}
