#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>

int main(int argc, char* argv[]){

	int fds[2];
	int p = pipe(fds);

//	for(int i = 0; i<2; i++)
//		printf("fds[%d] = %d \n", i, fds[i]);

	int x = fork();

	if(x == 0){
		int bw = write(fds[1], "Hello", 6);
		printf("Child write hello \n");
//		sleep(5);
	}
	else{
		char buff[100];
		int br = read(fds[0], buff, 100);
		//perror("");
		printf("Parent reads %s\n", buff);
	}
	return 0;
}
