#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/wait.h>
#include<sys/select.h>

int main(int argc, char* argv[]){

	int fd1[2], fd2[2];
	int br, bw, w;
	char buff[100];
	fd_set readfds;

	int p1 = pipe(fd1);
	int p2 = pipe(fd2);
		
	int x = fork();
	
	while(1){
		
		if(x == 0){	
			FD_ZERO(&readfds);
			FD_SET(STDIN_FILENO, &readfds);
			FD_SET(fd2[0], &readfds);

			select(FD_SETSIZE, &readfds, NULL, NULL, NULL);

			if (FD_ISSET(STDIN_FILENO, &readfds)) {
				br = read(STDIN_FILENO, buff, 100);
				bw = write(fd1[1], buff, br);
			}

			if (FD_ISSET(fd2[0], &readfds)) {
				br = read(fd2[0], buff, 100);
				//if(br > 0)
				//	printf("Child Read Succesfully: \n");
				printf("Child Read Succesfully: \n");

				write(STDOUT_FILENO, buff, br);
			}
			
		}

		else{
			FD_ZERO(&readfds);
			FD_SET(STDIN_FILENO, &readfds);
			FD_SET(fd1[0], &readfds);

			select(FD_SETSIZE, &readfds, NULL, NULL, NULL);

			if (FD_ISSET(fd1[0], &readfds)) {
				br = read(fd1[0], buff, 100);
				//if(br > 0)
				//	printf("Parent Read Succesfully: \n");

				printf("Parent Read Succesfully: \n");
				write(STDOUT_FILENO, buff, br);
			}

			if (FD_ISSET(STDIN_FILENO, &readfds)) {
				br = read(STDIN_FILENO, buff, 100);
				write(fd2[1], buff, br);
			}
		}
	}
	return 0;
}

