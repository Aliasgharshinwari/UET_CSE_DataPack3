#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<sys/wait.h>

int main(int argc, char* argv[]){

	int fds[2];
	int br, bw, w;
	char buff[100];
	int N = 3;
	int pid, i;

	int p = pipe(fds);

	for(i =0; i<N; i++){
		pid = fork();

		if(pid == 0)
			break;
	}


	if(pid > 0){
		for(i = 0; i<N; i++){
			bw = write(fds[1], "Hello", 6);
			w = wait(NULL);
		}
	}

	else{

		br = read(fds[0], buff, 6);
		printf("Child %d read %s\n",i, buff);

	}
	return 0;
	
}
