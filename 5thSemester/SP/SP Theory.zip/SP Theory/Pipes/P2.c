#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<sys/wait.h>

int main(int argc, char* argv[]){

	int fds[2];
	int br, bw, w;
	char buff[100];

	int p = pipe(fds);

	int x = fork();

	if(x == 0){
		br = read(STDIN_FILENO, buff, 100);
		bw = write(fds[1], buff, br);
//		sleep(2);
		br = read(fds[0], buff, 100);
		if(br > 0)
			printf("Child Read Succesfully\n");

		write(STDOUT_FILENO, buff, br);
	}

	else{
		br = read(fds[0], buff, 100);
		if(br > 0)
			printf("Parent Read Succesfully\n");

		write(STDOUT_FILENO, buff, br);

		br = read(STDIN_FILENO, buff, 100);
		write(fds[1], buff, br);

		w = wait(NULL);
	}
	return 0;
}
