#include<stdio.h>
#include<sys/wait.h>
#include<unistd.h>
#include<string.h>
#include<sys/stat.h>
#include<fcntl.h>

int main(int argc, char *argv[]){
	
	int fd1 = open("f1.txt", O_RDONLY);
	if(fd1 == -1){
		perror("Error: ");
	}

	int fd2 = open("f2.txt", O_WRONLY | O_CREAT, S_IRUSR | O_APPEND);
	
	char bffr[100];
		
	int br,bw;
	//while((br = read(fd1, bffr, sizeof(bffr))) != 0){
		br = read(fd1, bffr, sizeof(bffr));
		printf("br = %d\n", br);
		bw = write(fd2, bffr, br);
	//}

	close(fd1);
	close(fd2);
	return 0;
}
