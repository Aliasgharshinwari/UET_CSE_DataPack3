#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<signal.h>

void sigalrm(int signo){
	return;
}
int main(){
	
	struct sigaction act;
	act.sa_handler = sigalrm;
	act.sa_flags = 0;
	sigemptyset(&act.sa_mask);
	
	sigaction(SIGINT, &act, NULL);
	printf("Program Started\n");
	alarm(5);
	pause();
	
	printf("Program Terminated\n");

	return 0;
}
