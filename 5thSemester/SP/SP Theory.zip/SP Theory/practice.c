#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[]){
	char* dir;
	dir = getenv("PATH");	
	printf("%s\n",dir);
	return 0;
}
