#include<stdio.h>
#include<sys/wait.h>
#include<unistd.h>

int main(int argc, char *argv[]){
	int arr[20] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
	int status;
	int pid;
	printf("In Parent Process\n");

	for(int i = 1; i<argc; i++){
		pid = fork();
		if(pid == 0){
			printf("In child Process %i\n",i);
			execlp(argv[i], argv[i], NULL);
		}

	}

	if(pid > 0){
		for(int i = 0; i<10; i++){
			int r = wait(&status);
			
			//if(WIFEXITED(status) && !WEXITSTATUS(status) )
			//	printf("Child %d terminated normally\n",i);
			// if(WIFEXITED(status))
			//	printf("Child %d terminated with return status %d\n", i, WEXITSTATUS(status));
		}

	}
	
	return 0;
}
