#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int main(){
	int perm = S_IRWXU;
	int fd1 = open("f1.txt", O_RDONLY);
	int fd2 = open("f2.txt", O_RDONLY);
	int fd3 = open("f3.txt", O_WRONLY | O_CREAT, perm);
	
	fd_set myreadyset;
	
	FD_ZERO(&myreadyset);
	FD_SET(STDIN_FILENO, &myreadyset);
	FD_SET(fd2, &myreadyset);

//	for(int i = 0; i<FD_SETSIZE; i++){
//		printf("%d\n", myreadyset[i]);
//	}
	//int br = 1;
	//int bw;
	//char bffr[1];
	int maxfd = (STDIN_FILENO > fd2) ? STDIN_FILENO : fd2 ;

	int nrf = select(maxfd + 1, &myreadyset, NULL, NULL, NULL);
	printf("nrf = %d\n", nrf);

	return 0;
}
