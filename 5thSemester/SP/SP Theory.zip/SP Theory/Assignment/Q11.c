#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<fcntl.h>

int fd_rd[2];
int fd_wr[2];

char *rd_names[2] = {"f1.txt","f2.txt"};
char *wr_names[2] = {"f1_Copy.txt","f2_Copy.txt"};

void *COPY(void* arg){
	int br, bw;
	char buff[100];
	
	while((br = read(fd_rd[*(int *)arg], buff, 100)) !=0){
		bw = write(fd_wr[*(int *)arg], buff, br);
	}
}

int main(){
	pthread_t tid[2];
	int perm = S_IRWXU;
	int args[2] ={0, 1};
	
	
	for(int i=0; i<2; i++){
		fd_rd[i] = open(rd_names[i], O_RDONLY);
		fd_wr[i] = open(wr_names[i], O_WRONLY | O_CREAT, perm);
	}
	
	for(int i =0; i<2; i++){
		pthread_create(&tid[i], NULL, COPY, (void *)&args[i]);
	}
	
	for(int i =0; i<2; i++){
		pthread_join(tid[i], NULL);
	}
	
	printf("Both Files Copied Successfully\n");
	
	return 0;
}

