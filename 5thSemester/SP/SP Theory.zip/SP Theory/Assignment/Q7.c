#include<stdio.h>
#include<sys/wait.h>
#include<unistd.h>

int main(int argc, char *argv[]){
	int arr[1000];
	int status, pid;
	int res = 0;
	int sum = 0;
	int total = 0;	
	int i, fd[2];
	
	for(i = 0; i<1000; i++){
		arr[i] = i;
	}
	
	int p = pipe(fd);
	
	for(i = 0; i<3; i++){
		pid = fork();
		if(pid < 0){
			perror("fork");
			return 1;
		}
	
		if(pid == 0){ break; }

	}
	
	if(pid == 0 && i == 0){//First Child's Code
		for(int j = 0; j<=1000/3 *(1 + i); j++){
			res += arr[j];
		}
		if(write(fd[1], &res, sizeof(sum)) < 0){
			perror("write");
			return 1;
		}
		return 0;
	}
	
	if(pid == 0 && i ==1){//Second Child's Code
		for(int j = 334; j<=1000/3 *(1 + i); j++){
			res += arr[j];
		}
		
		if(write(fd[1], &res, sizeof(sum)) < 0){
			perror("write");
			return 1;
		}
		return 0;
	}
	
	if(pid == 0 && i ==2){//Third Child's Code
		for(int j = 667; j<=1000/3 *(1 + i); j++){
			res += arr[j];
		}
		
		if(write(fd[1], &res, sizeof(sum)) < 0){
			perror("write");
			return 1;
		}
		
		return 0;
	}

	if(pid > 0){
		for(i = 0; i<3; i++){
			int r = wait(&status);
			if(r < 0){
				perror("wait");
				return 1;
			}
			if(WIFEXITED(status)){
				printf("Child %d terminated with return status %d\n", i, WEXITSTATUS(status));
				
				if(read(fd[0], &sum, sizeof(sum)) < 0){
					perror("read");
					return 1;
				}
				total += sum;
			}
		}
		
		printf("Sum = %d, ", total);
	}
	return 0;
}

