#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<dirent.h>
#include<string.h>
#include<sys/stat.h>
#include<sys/wait.h>
#include<errno.h>

int bw, br;	
int fd1[2];	
int fd2[2];

void read_file(char* filename){
	char buff2[10];
	int bw, br;
	
	int fd = open(filename, O_RDONLY);
	if(fd == -1){
		perror("open");
		exit(-1);
	}
	
	while((br = read(fd, buff2, 10)) !=0){
		if(br == -1){
			perror("read");
			exit(-1);
		}
		bw = write(fd1[1], buff2, br);
		if(bw == -1){
			perror("write");
			exit(-1);
		}
	}
	
	if(close(fd1[1]) == -1){ // Close the write end of the pipe
		perror("close");
		exit(-1);
	}
}

int main(int argc, char* argv[]){
	
	char buff[100];
	
	int p1 = pipe(fd1);
	if(p1 == -1){
		perror("pipe");
		exit(-1);
	}
	
	int p2 = pipe(fd2);
	if(p2 == -1){
		perror("pipe");
		exit(-1);
	}
	
	int x = fork();
	if(x == -1){
		perror("fork");
		exit(-1);
	}
	
	if(x == 0){
		if(close(fd1[1]) == -1){ // Close the write end of the pipe in the child process
			perror("close");
			exit(-1);
		}
		printf("CHILD CODE\n");
		bw = write(fd2[1], argv[1], strlen(argv[1]) + 1);
		if(bw == -1){
			perror("write");
			exit(-1);
		}
		
		sleep(2);
		
		while((br = read(fd1[0], buff, 100)) != 0){
			if(br == -1){
				perror("read");
				exit(-1);
			}
			bw = write(STDOUT_FILENO, buff, br);
			if(bw == -1){
				perror("write");
				exit(-1);
			}
		}
		
		printf("CHILD TERMINATED\n");
	}
	else{
		if(close(fd2[1]) == -1){ // Close the write end of the pipe in the parent process
			perror("close");
			exit(-1);
		}
		printf("PARENT CODE\n");
		char pipebuff[100]; // create a new buffer for pipe
    		
    		br = read(fd2[0], pipebuff, 100); // read into the new buffer
		if(br == -1){
			perror("read");
			exit(-1);
		}

		if(strcmp(pipebuff, argv[1]) == 0){
        		read_file(pipebuff); // buff still contains the directory name
        		//printf("INSIDE STRCMP\n");
    		}
    		
    		int r = wait(NULL);
    		if(r == -1){
    			perror("wait");
    			exit(-1);
    		}
    		printf("PARENT TERMINATED\n");
	}
	return 0;
}S
