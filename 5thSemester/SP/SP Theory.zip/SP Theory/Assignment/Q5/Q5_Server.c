#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<dirent.h>
#include<string.h>
#include<sys/stat.h>
#include<errno.h>

int perm = S_IRWXU;
int fd;
	
void read_file(char* filename){
	char buff2[10];
	int bw, br;
	
	int fd_file = open(filename, O_RDONLY);
	
	while((br = read(fd_file, buff2, 10)) !=0){
		bw = write(fd, buff2, br);
	}
}


int main(int argc, char* argv[]){
	
	int bw, br;	
	char buff[100];	
	
	int m = mkfifo("myfifo1", perm);
	if(m == -1 && errno != EEXIST){
		perror("mkfifo");
		return -1;
	}
	
	fd = open("myfifo1", O_RDWR); 
	if(fd == -1){
		perror("open");
		return -1;
	}
	
	br = read(fd, buff, 100);
	if(br > 0){
		read_file(buff);
		printf("Successfully Read File\n");
	}
	
	if(close(fd) == -1){
		perror("close");
		return -1;
	}
	
	return 0;
}

