#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

int arr[100];
int sum = 0;
pthread_mutex_t lock;

void *SumArray(void* arg){
	int local_sum = 0;
	
	for(int i = 0; i<100; i++){
		local_sum +=arr[i];
	}
	
	pthread_mutex_lock(&lock);
	sum = local_sum;
	pthread_mutex_unlock(&lock);
	
	return NULL;
}

void *SearchArray(void* arg){
	
	for(int i = 0; i<100; i++){
		if(arr[i] == *(int *)arg){
			pthread_mutex_lock(&lock);
			printf("x = %d found at %d\n", *(int *)arg, i);
			pthread_mutex_unlock(&lock);
		}
	}
	
	return NULL;
}

int main(){

	pthread_t tid[2];
	int x = 4;
	for(int i =0; i<100; i++){
		arr[i] = i;
	}
	
	if (pthread_mutex_init(&lock, NULL) != 0) {
        printf("\n mutex init has failed\n");
        return 1;
    }
	
	if(pthread_create(&tid[0], NULL, SumArray, NULL) != 0){
		printf("\nThread creation failed. Exiting now.");
		return 1;
	}
	
	if(pthread_create(&tid[1], NULL, SearchArray, (void *)&x) != 0){
		printf("\nThread creation failed. Exiting now.");
		return 1;
	}
	
	
	for(int i =0; i<2; i++){
		if(pthread_join(tid[i], NULL) != 0){
			printf("\nThread join failed. Exiting now.");
			return 1;
		}
	}
	
	printf("Sum = %d\n", sum);
	pthread_mutex_destroy(&lock);
	return 0;
}

