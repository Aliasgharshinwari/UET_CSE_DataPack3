#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<dirent.h>
#include<string.h>

int main(int argc, char* argv[]){
	
	
	struct dirent *direntp;
	int flag = 0;
	DIR *dirp = opendir(argv[1]);
		
	if(dirp == NULL)
		return -1;
		
	while((direntp = readdir(dirp)) != NULL){
			
			
		if(strcmp(direntp->d_name, ".") == 0 || strcmp(direntp->d_name, "..") == 0)
			continue;
			
		if(strcmp(direntp->d_name, argv[2]) == 0){
			flag = 1;
			break;
		}
	}
	
	if(flag)
		printf("File %s Found in %s\n", argv[2], argv[1]);
	else
		printf("File %s Not Found in %s\n", argv[2], argv[1]);	
	
	return -1;
}
