#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <N>\n", argv[0]);
        exit(-1);
    }

    int N = atoi(argv[1]);
    sigset_t set;
    int sig;

    /* Initialize the signal set */
    sigemptyset(&set);

    /* Add SIGUSR1 to the set */
    sigaddset(&set, SIGUSR1);

    /* Block SIGUSR1 */
    if (sigprocmask(SIG_BLOCK, &set, NULL) == -1) {
        perror("sigprocmask");
        exit(-1);
    }

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(-1);
    }

    if (pid == 0) {  // Child process
        for (int i = 0; i < N; i++) {
            kill(getppid(), SIGUSR1);
            sleep(1);
        }
        exit(0);
    } else {  // Parent process
        for (int i = 0; i < N; i++) {
            sigwait(&set, &sig);  // Wait for SIGUSR1
        }
        printf("Received %d SIGUSR1 signals\n", N);
        wait(NULL);  // Wait for child process to finish
    }

    return 0;
}

