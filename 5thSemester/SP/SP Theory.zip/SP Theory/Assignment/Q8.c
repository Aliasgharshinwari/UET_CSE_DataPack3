#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>
#include<sys/wait.h>

int count = 0;

void my_handler(int sig_no){
	count++;
	write(STDOUT_FILENO, "SIGUSR1 count \n", 15);
}

int main(int argc, char* argv[]){
	
	int pid;
	
	struct sigaction my_action;
	
	my_action.sa_flags = 0;
	my_action.sa_handler = my_handler;
	sigemptyset(&my_action.sa_mask);

	sigaction(SIGUSR1, &my_action, NULL);
	
	pid = fork();
	
	if(pid == 0){
		
		for(int i = 0; i < 3; i++){
			kill(getppid(), SIGUSR1);
		}
	}
	
	if(pid > 0){
		
		for(int i = 0; i < 3; i++){
			pause();
		}
		
		wait(NULL);	
	}
	
	return 0;
}
