#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>

sigset_t myset;
int x;

void my_wait(){

	if(x > 0){
		sigsuspend(&myset);
	}
	
}

void my_handler(int sig_no){
	
	printf("\nChild has been terminated..\n");
}

int main(int argc, char* argv[]){
	
	struct sigaction my_action;
	
	my_action.sa_flags = 0;
	my_action.sa_handler = my_handler;
	sigemptyset(&my_action.sa_mask); 
	
	sigemptyset(&myset); 
	sigfillset(&myset);
	sigdelset(&myset, SIGCHLD);
	
	if(sigaction(SIGCHLD, &my_action, NULL) < 0){
		perror("sigaction");
		exit(-1);
	}

	x = fork();
	
	if(x < 0){
		perror("fork");
		exit(-1);
	}
	else if(x > 0){
		printf("\nParent Waiting..\n");
		my_wait();				
		printf("\nParent Waited successfully..\n");
	}
	
	return 0;
}

