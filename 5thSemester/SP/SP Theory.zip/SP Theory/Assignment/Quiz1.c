#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<dirent.h>
#include<string.h>

int main(int argc, char* argv[]){
	char buff[100];
	
	struct dirent *direntp;
	
	DIR *dirp = opendir(argv[1]);
	
	while((direntp = readdir(dirp))!= NULL){
		//direntp = readdir(dirp);
		
		if(strcmp(direntp->d_name, ".") == 0 || strcmp(direntp->d_name, "..") == 0)
			continue;
		
		if(strcmp(direntp->d_name, argv[2]) == 0){
			printf("File Found\n");
			return 0;
		}
	}
	
	printf("File Not Found\n");	
	return 0;
}
