#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<dirent.h>
#include<string.h>

int main(int argc, char* argv[]){
	
	struct dirent *direntp;
	
	for(int i=2; i < argc; i++){

		DIR *dirp = opendir(argv[i]);
		
		if(dirp == NULL)
			return -1;
		
		while((direntp = readdir(dirp)) != NULL){
			
			
			if(strcmp(direntp->d_name, ".") == 0 || strcmp(direntp->d_name, "..") == 0)
				continue;
			
			if(strcmp(direntp->d_name, argv[1]) == 0){
				printf("File %s Found in %s\n", argv[1], argv[i]);
			}
		}
		
	}
	return 0;
}
