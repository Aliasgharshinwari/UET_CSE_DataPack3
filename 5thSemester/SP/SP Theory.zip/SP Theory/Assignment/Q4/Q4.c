#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<dirent.h>
#include<string.h>
#include<sys/stat.h>
#include<sys/wait.h>
#include<errno.h>

int bw, br;	
int fd1[2];	
int fd2[2];

void list(char* buff){
	
	int bw;
	DIR *dirp = opendir(buff);
	struct dirent *direntp;
		
	if(dirp == NULL){
		perror("opendir");
		return;
	}
		
	while((direntp = readdir(dirp)) != NULL){
		if(strcmp(direntp->d_name, ".") == 0 || strcmp(direntp->d_name, "..") == 0)
			continue;
	
		bw = write(fd1[1], direntp->d_name, strlen(direntp->d_name) + 1);
		if(bw == -1){
			perror("write");
			return;
		}
		bw = write(fd1[1], " ", 2);
		if(bw == -1){
			perror("write");
			return;
		}
	}
	
	if(closedir(dirp) == -1){
		perror("closedir");
		return;
	}
}

int main(int argc, char* argv[]){
	
	char buff[100];
	
	strcpy(buff, argv[1]);
	
	int p1 = pipe(fd1);
	if(p1 == -1){
		perror("pipe");
		return -1;
	}
	
	int p2 = pipe(fd2);
	if(p2 == -1){
		perror("pipe");
		return -1;
	}
	
	int x = fork();
	
	if(x == -1){
		perror("fork");
		return -1;
	}
	
	if(x == 0){
		printf("CHILD CODE\n");
		bw = write(fd2[1], "CONTENTS", 9);
		if(bw == -1){
			perror("write");
			return -1;
		}
		br = read(fd1[0], buff, 100);
		if(br == -1){
			perror("read");
			return -1;
		}
		bw = write(STDOUT_FILENO, buff, 100);
		if(bw == -1){
			perror("write");
			return -1;
		}
	}
	else{
		printf("PARENT CODE\n");
		char pipebuff[100]; // create a new buffer for pipe
    		br = read(fd2[0], pipebuff, 100); // read into the new buffer
		if(br == -1){
			perror("read");
			return -1;
		}

		if(strcmp(pipebuff, "CONTENTS")==0){
        		list(buff); // buff still contains the directory name
    		}
	}
	return 0;
}

