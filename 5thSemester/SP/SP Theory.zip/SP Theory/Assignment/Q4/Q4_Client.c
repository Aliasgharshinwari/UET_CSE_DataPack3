#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<dirent.h>
#include<string.h>
#include<errno.h>
#include<sys/stat.h>

int main(int argc, char* argv[]){
	
	char buff[100];
	int perm = S_IRWXU;
	int bw, br;	
	int m = mkfifo("myfifo1", perm);
	
	if(m < 0 && errno != EEXIST){
		perror("mkfifo");
		return -1;
	}
	
	int fd = open("myfifo1", O_RDWR);
	 
	if(fd == -1){
		perror("open");
		return -1;
	}
		
	bw = write(fd, argv[1], strlen(argv[1])+1);
	if(bw == -1){
		perror("write");
		return -1;
	}
	
	sleep(1);
	while((br = read(fd, buff, 100)) != 0){
		if(br == -1){
			perror("read");
			return -1;
		}
		bw = write(STDOUT_FILENO, buff, br);
		if(bw == -1){
			perror("write");
			return -1;
		}
	}
	
	if(close(fd) == -1){
		perror("close");
		return -1;
	}
	
	return 0;
}

