#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<dirent.h>
#include<string.h>
#include<sys/stat.h>
#include<errno.h>

int perm = S_IRWXU;
int bw, br, fd;	
	
void list(char* buff){
	
	struct dirent *direntp;
	DIR *dirp = opendir(buff);
		
	if(dirp == NULL){
		perror("opendir");
		return;
	}
		
	while((direntp = readdir(dirp)) != NULL){
		if(strcmp(direntp->d_name, ".") == 0 || strcmp(direntp->d_name, "..") == 0)
			continue;
	
		bw = write(fd, direntp->d_name, strlen(direntp->d_name) + 1);
		if(bw == -1){
			perror("write");
			return;
		}
		bw = write(fd, " ", 2);
		if(bw == -1){
			perror("write");
			return;
		}
	}
	
	if(closedir(dirp) == -1){
		perror("closedir");
		return;
	}
}

int main(int argc, char* argv[]){
	
	char buff[100];	
	
	int m = mkfifo("myfifo1", perm);
	if(m == -1 && errno != EEXIST){
		perror("mkfifo");
		return -1;
	}
	
	fd = open("myfifo1", O_RDWR); 
	if(fd == -1){
		perror("open");
		return -1;
	}
	
	br = read(fd, buff, 100);
	if(br > 0){
		list(buff);
		printf("Successfully Written names\n");
	}
	
	if(close(fd) == -1){
		perror("close");
		return -1;
	}
	
	return 0;
}

