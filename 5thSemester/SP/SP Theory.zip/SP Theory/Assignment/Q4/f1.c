#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<dirent.h>
#include<string.h>
#include<errno.h>
#include<sys/stat.h>

int main(int argc, char* argv[]){
	
	char buff[100];
	int perm = S_IRWXU;
	int bw, br;	
	int fd = mkfifo("myfifo1", perm);
	
	if(fd == -1 && errno !=EEXIST)
		return -1;
		
	bw = write(fd, argv[1], strlen(argv[1])+1);
	//printf()
	sleep(10);
	
	br = read(fd, buff, 100);
	printf("%s", buff);
	return 0;
}
