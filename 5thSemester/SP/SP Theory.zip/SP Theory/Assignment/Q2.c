#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<dirent.h>
#include<string.h>

int main(int argc, char* argv[]){
	
	struct dirent *direntp;
	char bff[100];
	
	DIR *dirp = opendir(argv[1]);
	
	if(dirp == NULL){
		fprintf(stderr, "Error getting current path\n");
		return -1;
	}
	
	if(getcwd(bff, sizeof(bff)) == NULL){	
		fprintf(stderr, "Error getting current path\n");
		return -1;
	}
	
	printf("CURRENT WORKING DIR = %s\n", bff);
	
	while((direntp = readdir(dirp)) != NULL){
					
		if(strcmp(direntp->d_name, ".") == 0 || strcmp(direntp->d_name, "..") == 0)
			continue;
			
		printf("%s  ",direntp->d_name);	
	}
		
	printf("\n");
	return 0;
}
