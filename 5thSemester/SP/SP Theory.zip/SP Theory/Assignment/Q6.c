#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/wait.h>

int main(int argc, char* argv[]){

	int fd1[2], fd2[2];
	int br, bw, w;
	char buff[100];

	int p1 = pipe(fd1);
	int p2 = pipe(fd2);
	

	fd_set myreadset;
		
	
	int x = fork();
	
	
	while(1){
		FD_ZERO(&myreadset);
			
		FD_SET(fd1[0] , &myreadset);	
		FD_SET(fd2[0] , &myreadset);	
		FD_SET(STDIN_FILENO , &myreadset);	
			
		int maxfd;
		if(fd1 > fd2 && fd1 > STDIN_FILENO)
			maxfd = fd1[0];
		
		else if(fd2 > fd1 && fd2 > STDIN_FILENO)
			maxfd = fd2[0];
		
		else
			maxfd = STDIN_FILENO;
		
	
		
		if(x == 0){
	
			
			int nrf = select(maxfd + 1, &myreadset, NULL, NULL, NULL);

			if(FD_ISSET(STDIN_FILENO, &myreadset)){
		
				br = read(STDIN_FILENO, buff, 100);
				bw = write(fd1[1], buff, br);
			}

			if(FD_ISSET(fd2[0], &myreadset)){

				br = read(fd2[0], buff, 100);
				if(br > 0)
					printf("Child Read Succesfully: \n");

				write(STDOUT_FILENO, buff, br);
			}
		}

		else{
			
			int nrf = select(maxfd + 1, &myreadset, NULL, NULL, NULL);
			
			if(FD_ISSET(fd1[0], &myreadset)){
		
				br = read(fd1[0], buff, 100);
				if(br > 0)
					printf("Parent Read Succesfully: \n");

				write(STDOUT_FILENO, buff, br);
			}
			
			if(FD_ISSET(STDIN_FILENO, &myreadset)){
		
				br = read(STDIN_FILENO, buff, 100);
				write(fd2[1], buff, br);
			}
		}
	}
	return 0;
}
