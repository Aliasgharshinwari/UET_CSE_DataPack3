#include<stdio.h>
#include<unistd.h>

int main(int argc, char* argv[]){
	
	int i;
	printf("hello");
	fprintf(stderr,"hello");
	for(i = 0; i<3; i++)
		fork();
	printf("hello\n");
	return 0;
}
