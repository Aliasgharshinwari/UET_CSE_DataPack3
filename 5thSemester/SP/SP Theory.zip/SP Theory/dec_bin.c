#include<stdio.h>
#include<stdlib.h>

void dec_to_binary(int num){
	int binary[32];
	int i =0;
	
	
	while(num > 0){
		binary[i] = num % 2;
		num = num/2;
		i++;
	}

	for(int j = i -1; j>=0; j-- ){
		printf("%d", binary[j]);
	}

	printf("\n");

}

int main(int argc, char* argv[]){

	//printf("%d\n",atoi(argv[1]));
	dec_to_binary(atoi(argv[1]));
	return 0;
}
