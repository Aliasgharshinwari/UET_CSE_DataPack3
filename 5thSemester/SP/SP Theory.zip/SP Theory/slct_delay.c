#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>

int main(int argc, char* argv[]){
	
	struct timeval mytime;
	mytime.tv_sec = 5;
	mytime.tv_usec = 0;

	printf("hello\n");
	
	select(1,NULL, NULL, NULL, &mytime);

	printf("world\n");

	return 0;
}
