#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(int argc, char *argv[]){
	int filedis;

	printf("%d", filedis);	
	if(close(filedis) == -1)
		perror("Error");
	else
		printf("File Closed Succesfully\n");
	return 0;
}
