#include<stdio.h>
#include<stdlib.h>

void print_pyramid(int n){

	for(int i = 0; i<n; i++){
		
		for(int j = 1; j<=(n - i); j++){
			printf(" ");
		}
		
		for(int k = 1; k<=i+1; k++){
			printf("*");
		}
		printf("\n");
	}
}

int main(int argc, char* argv[]){

	//printf("%d\n",atoi(argv[1]));
	print_pyramid(atoi(argv[1]));
	return 0;
}
