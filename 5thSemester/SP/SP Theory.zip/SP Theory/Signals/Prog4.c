#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>

int count = 0;

void my_handler(int sig_no){
	count++;
	printf("\nTerminatinngg..\n");
}

int main(int argc, char* argv[]){
	
	struct sigaction my_action;
	
	my_action.sa_flags = 0;
	my_action.sa_handler = my_handler;
	sigemptyset(&my_action.sa_mask);

	sigaction(SIGINT, &my_action, NULL);
	
	sleep(1);
	
	pause();
	
	//while(count < 10){}
	return 0;
}
