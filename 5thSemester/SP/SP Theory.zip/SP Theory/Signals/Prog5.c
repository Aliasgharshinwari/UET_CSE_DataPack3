#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>


void my_sigint_handler(int sig_no){
	
	printf("\nSIG INT..\n");
}

void my_sigquit_handler(int sig_no){
	
	printf("\nSIG QUIT..\n");
}

int main(int argc, char* argv[]){
	
	sigset_t myset;
	int x;
	struct sigaction my_sigint_action;
	struct sigaction my_sigquit_action;
	
	my_sigint_action.sa_flags = 0;
	my_sigint_action.sa_handler = my_sigint_handler;
	sigemptyset(&my_sigint_action.sa_mask);
	sigaction(SIGINT, &my_sigint_action, NULL);
	
	
	my_sigquit_action.sa_flags = 0;
	my_sigquit_action.sa_handler = my_sigquit_handler;
	sigemptyset(&my_sigquit_action.sa_mask);
	sigaction(SIGINT, &my_sigint_action, NULL);
	
	sigemptyset(&myset);
	sigaddset(&myset, SIGINT);
	sigaddset(&myset, SIGQUIT);
	
	sigprocmask(SIG_BLOCK, &myset, NULL);
	
	sigwait(&myset, &x);
	
	if(x == SIGINT){
		printf("WAITED FOR SIG INT\n");
	}
	
	else{
		printf("WAITED FOR SIG INT\n");	
	}
	return 0;
}
