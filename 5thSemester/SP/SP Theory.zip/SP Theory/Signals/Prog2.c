#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>

int main(int argc, char* argv[]){
	
	alarm(5);
//	printf("%d\n", NSIG);
	for(;;);
	
	return 0;
}
