#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>
#include<sys/wait.h>

volatile sig_atomic_t count = 0;
volatile sig_atomic_t print_flag = 0;

void my_handler(int sig_no){
	count++;
	print_flag = 1;
}

int main(int argc, char* argv[]){
	
	int pid;
	
	struct sigaction my_action;
	
	my_action.sa_flags = 0;
	my_action.sa_handler = my_handler;
	sigemptyset(&my_action.sa_mask);

	sigaction(SIGUSR1, &my_action, NULL);
	
	pid = fork();
	
	if(pid == 0){
		for(int i = 0; i < 3; i++){
			kill(getppid(), SIGUSR1);
		}
	}
	
	if(pid > 0){
		for(int i = 0; i < 3; i++){
			pause();
			if (print_flag) {
				printf("SIGUSR1 count = %d\n", count);
				print_flag = 0;
			}
		}
		
		wait(NULL);	
	}
	
	return 0;
}

