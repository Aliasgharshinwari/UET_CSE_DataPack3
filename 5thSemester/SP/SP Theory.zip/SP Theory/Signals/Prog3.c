#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>

int main(int argc, char* argv[]){
	
	int k = alarm(50);
	for(int i = 0; i <100000; i++)
		printf("Hello\n");
	
	int r = alarm(5);
	printf("Time Taken by Loop  = %d and k = %d\n", 50 - r, k);
	
	
	return 0;
}
