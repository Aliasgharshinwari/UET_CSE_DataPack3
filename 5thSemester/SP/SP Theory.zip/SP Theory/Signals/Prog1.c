#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>

int main(int argc, char* argv[]){
	
	sigset_t my_sigset;
	sigset_t old_sigset;
	
	sigemptyset(&my_sigset);
	
	sigaddset(&my_sigset, SIGINT);
	sigaddset(&my_sigset, SIGQUIT);
	
	//sigprocmask(SIG_SETMASK, &my_sigset, &old_sigset);
	
	//raise(SIGINT);
	
	for(;;);
	
	return 0;
}
