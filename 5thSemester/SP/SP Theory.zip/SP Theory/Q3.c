#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>

int main(int argc, char* argv[]){

	int arr[1000];
	int pid;
	int status;
	
	//initialize array
		for(int i=0; i<999; i++){
			arr[i] = i*1;
			}
	
	for(int i=0; i<3; i++){
	pid= fork();
	if(pid==0){
		break;
	}
	}
	
	for(int i=0; i<3; i++){
	if(pid==0){
		if(i==0){
		int sum;
			for(int i=0; i<=333; i++){
				sum += arr[i];
				 	
			}return sum;
		}
		if(i==1){
		int sum;
			for(int i=334; i<=666; i++){
				sum += arr[i]; 	
			} return sum;
		}
		if(i==2){
		int sum;
			for(int i=667; i<=999; i++){
				sum += arr[i]; 	
			}
		                   return sum;   } 
	
	}
	}
	
	if(pid>0){
		for(int i=0; i<3; i++){
			wait(&status);
		}
	}
	
	int result;
	if(WIFEXITED(status)){
		result += WEXITSTATUS(status);
	}
	
	printf("arr sum: %d\n", result);
	
	return 0;
}
