#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/wait.h>
#include<sys/stat.h>
#include<errno.h>
#include<string.h>

int main(){
	int perm = S_IRWXU;
	char buff[100];
	int br, bw;
	int nrf, maxfd;
	
	int r = mkfifo("chatfifo", perm);
	
	struct timeval mytime;
	mytime.tv_sec = 2;
	mytime.tv_usec = 0;

	if(r == -1 && errno != EEXIST){
		perror("mkfifo failed");
		return -1;
	}
	
	int fd = open("chatfifo", O_RDWR);
	

	fd_set myreadset;

		
	while(1){
		FD_ZERO(&myreadset);	
		FD_SET(fd, &myreadset);	
		FD_SET(STDIN_FILENO, &myreadset);	
	
		maxfd = (STDIN_FILENO > fd) ? STDIN_FILENO: fd;
	
		nrf = select(maxfd + 1, &myreadset, NULL, NULL, &mytime);
	
		
		if(FD_ISSET(STDIN_FILENO, &myreadset)){
		
			br = read(STDIN_FILENO, buff, 255);
			bw = write(fd, buff, br);
			
			if(strcmp(buff, "GB") == 0)
				break;

//			if(strcmp(buff, "GB") == 0)
//				return 0;

//			printf("INSIDE IF 1\n");
		}
		
		if(FD_ISSET(fd, &myreadset)){
		
			br = read(fd, buff, 255);
			bw = write(STDOUT_FILENO, buff, br);
			
			if(strcmp(buff, "GB") == 0)
				break;
			//printf("%s\n", buff);
//			printf("INSIDE IF 2\n");
		}
	
		//printf("Buffer Contains %s\n", buff);		
		
	}
	
	unlink("chatfifo");
	return 0;
}
