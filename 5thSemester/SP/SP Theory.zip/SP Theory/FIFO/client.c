#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/wait.h>
#include<sys/stat.h>
#include<errno.h>
#include<string.h>


int main(){
	int perm = S_IRWXU;

	char buff[100];

	int r1 = mkfifo("myfifo1", perm);
	int r2 = mkfifo("myfifo2", perm);
	
	if(r1 == -1 && errno != EEXIST){
		perror("mkfifo failed");
		return -1;
	}

	if(r2 == -1 && errno != EEXIST){
		perror("mkfifo failed");
		return -1;
	}
	
	int fd1 = open("myfifo1", O_RDWR);
	int fd2 = open("myfifo2", O_RDWR);
	
	int bw = write(fd1, "Time?", 6);
	int br = read(fd2, buff, 255);
	printf("Current D&T is: %s", buff);
	return 0;
}
