#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/wait.h>
#include<sys/stat.h>
#include<errno.h>
#include<string.h>

#include<time.h>
//#include<sys/types.h>

int main(){
	int perm = S_IRWXU;

	char buff[100];

	int r1 = mkfifo("myfifo1", perm);
	int r2 = mkfifo("myfifo1", perm);

	if(r1 == -1 && errno != EEXIST){
		perror("mkfifo failed ");
		return -1;
	}
	
	if(r2 == -1 && errno != EEXIST){
		perror("mkfifo failed ");
		return -1;
	}
	
	int fd1 = open("myfifo1", O_RDWR);
	int fd2 = open("myfifo2", O_RDWR);

	int br = read(fd1, buff, 255);
	
	time_t t = time(NULL);

	char* time_str = ctime(&t);

	int bw = write(fd2, time_str, strlen(time_str)+1);
	return 0;
}
