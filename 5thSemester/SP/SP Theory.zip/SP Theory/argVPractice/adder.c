#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>

int main(int argc, char* argv[]){

	int res;
	printf("argc %d",atoi(argv[0]));
//	if(argc != 3){
	
//		printf("Error: Invalid Args\n");
//		return -1;
//	}
	for(int i=0; i<argc; i++)
		res += atoi(argv[i]);

	printf("Sum = %d\n",res);
	return res;
}
