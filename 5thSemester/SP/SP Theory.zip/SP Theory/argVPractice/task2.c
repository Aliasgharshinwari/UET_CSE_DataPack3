#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>

int main(int argc, char* argv[]){

	int pid;
	int r, s;
	
	//printf("%d\n",x);
	for(int i = 0; i<2; i++){
		pid = fork();

		if(pid == 0 && i == 0){
			execv("./adder.o",argv);
		}

		if(pid == 0 && i == 1){
			execv("./adder.o", &argv[4]);
		}
	}
	if(pid > 0){
		for(int i = 0; i<2; i++){
			r = wait(&s);
			if(WIFEXITED(s)){
				printf("Child %d Terminated with status %d \n", i, WEXITSTATUS(s));
			}
		}
	}
	return 0;
}
